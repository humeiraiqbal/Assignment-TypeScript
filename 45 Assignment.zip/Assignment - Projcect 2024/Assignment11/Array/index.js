//Names: Store the names of a few of your friends in a array called names. Print each person’s name by accessing each element in the list, one at a time.
let name = ["Bushra", "Sehar", "Adeeba"];
console.log(name);
console.log(name[0]);
console.log(name[1]);
console.log(name[2]);
console.log(name[0]);
1;
export {};
