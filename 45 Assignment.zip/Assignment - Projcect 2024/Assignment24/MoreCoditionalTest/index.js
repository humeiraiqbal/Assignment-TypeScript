// More Conditional Tests: You don’t have to limit the number of tests you create to 10. If you want to try more comparisons, write more tests. Have at least one True and one False result for each of the following:
// • Tests for equality and inequality with strings
let name = "Humeira";
// console.log("Equality Test: ", name as string === "Humeira");
// console.log ("Inequality Test: ", name as string !== "Humeira");
// • Tests using the lower case function
// console.log("Lower case function: ", name.toLowerCase() === "humeira" );
// console.log("Lower case function: ", name.toLowerCase() === "Humeira" );
// • Numerical tests involving equality and inequality, greater than and less than, greater than or equal to, and less than or equal to
// let num1: number = 5;
// let num2: number = 3;
// console.log("Numerical test: " , num1 ===5);
// console.log("Numerical test: " , num1 !==5);
// // • Tests using "and" and "or" operators
// console.log(num1 ===5 &&  num2 ===3);
// console.log(num1===5 || num2 ===3);
// // • Test whether an item is in a array
let oddNumbers = [1, 3, 5, 7, 9];
console.log(oddNumbers.includes(7));
// • Test whether an item is not in a array
console.log(oddNumbers.includes(10));
export {};
