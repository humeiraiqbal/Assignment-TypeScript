// Changing Guest List: You just heard that one of your guests can’t make the dinner, so you need to send out a new set of invitations. You’ll have to think of someone else to invite.

// • Start with your program from Exercise 14. Add a print statement at the end of your program stating the name of the guest who can’t make it.

// • Modify your list, replacing the name of the guest who can’t make it with the name of the new person you are inviting.

// • Print a second set of invitation messages, one for each person who is still in your list.





let guestList: string[] = ["Bushra","Adeeba","Saira","Sana"];

let absentguest: string ="Bushra ";
let newGuest = "Shazia";
guestList[0]=newGuest;

let Message2: string = `${absentguest} is not coming.`;
console.log(Message2);

for (let i = 0;  i < guestList.length; i++)  
{
    console.log(" Dear Ms\n" , guestList[i] ,"\n It is our Pleasure to Invite you for the dinner tonight/n Thank You");
}

