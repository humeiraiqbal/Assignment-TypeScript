console.log('Abraham Lincoln said,"All that I am, or hope to be, I owe to my angel mother"');
export {};
