let name: "Humeira Iqbal"
console.log("Hello, Humeira Would you like to learn some Python Today.")