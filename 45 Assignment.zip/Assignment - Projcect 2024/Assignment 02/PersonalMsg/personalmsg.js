let name;
console.log("Hello, Humeira Would you like to learn some Python Today.");
export {};
