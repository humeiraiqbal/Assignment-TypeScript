"use strict";
// They think of something you could store in a TypeScript Object. Write a program that creates Objects containing these items.
Object.defineProperty(exports, "__esModule", { value: true });
let myBio = {
    name: "Hammmad Ali",
    Age: 40,
    Qualification: "Masters"
};
console.log(myBio);
