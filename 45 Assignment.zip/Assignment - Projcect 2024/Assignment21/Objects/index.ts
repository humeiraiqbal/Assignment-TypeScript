/*They think of something you could store in a TypeScript Object. 
Write a program that creates Objects containing these items.*/

// Interface is used to define data types in the object
interface type { name: string, Age: number, Qualification: string}


let myBio : type = {
    name: "Hammmad Ali",
    Age: 40,
    Qualification: "Masters"

}

console.log(myBio);
