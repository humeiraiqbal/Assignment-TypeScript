// Your Own Array: Think of your favorite mode of transportation, such as a motorcycle or a car, and make a list that stores several examples. Use your list to print a series of statements about these items, such as “I would like to own a Honda motorcycle.”

let favoritetransportation: Array<[transport: string, brand: string ]> = []

favoritetransportation.push(["Car","Toyota"])
favoritetransportation.push(["Motorcycle","Honda"])
favoritetransportation.push(["Car","Honda"])
 
// for (let i:number = 0; i; < favoritetransportation.length ; i++ ) 
// {
     let message: string ="I would like to own a "
//      console.log(favoritetransportation[i]);
// }
console.log(`${message} ${favoritetransportation}`)