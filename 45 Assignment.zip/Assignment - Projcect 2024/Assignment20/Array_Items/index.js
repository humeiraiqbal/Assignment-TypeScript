/*Think of something you could store in a array. For example, you could make
a list of mountains, rivers, countries, cities, languages, or anything else you’d like.
 Write a program that creates a list containing these items.*/
var mountains = ["K2", "Hindukash", "Himaliya", "Mount Everest"];
console.log("List of locations");
// 1st Method:
// mountains.forEach(mountains=> {console.log(mountains)});
//  2nd Method:
for (var i = 0; i < mountains.length; i++) {
    console.log(mountains[i]);
}
;
