var animal = ["Cat", "Dog", "Horse"];
animal.forEach(function (animal) {
    console.log("A ".concat(animal, " would be a great pet"));
});
console.log("Any of these pet would make a great pet");
// let animals:string[] = ["Parrot", "Dog", "Cat", "Elephant"];
// animals.forEach(animal => {
//     console.log(`A ${animal} would make a great pet.');
//   console.log("Any of these animals would make a great pet!")
