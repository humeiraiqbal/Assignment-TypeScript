/*Conditional Tests: Write a series of conditional tests. Print a statement describing each test and your prediction for the results of each test. Your code should look something like this:

let car = 'subaru';

console.log("Is car == 'subaru'? I predict True.")

console.log(car == 'subaru')

• Look closely at your results, and make sure you understand why each line evaluates to True or False.

• Create at least 10 tests. Have at least 5 tests evaluate to True and another 5 tests evaluate to False.*/

let car = 'subaru';
// Test 1
console.log("Is car == 'subaru'? I predict True.")

console.log(car == 'subaru')

console.log("Is car !== 'subaru'? I predict True.")

console.log(car !== 'subaru')



// Test 2

console.log("Is car length <= 4'? I predict True.")

console.log(car.length <= 4);

console.log("Is car length >= 4'? I predict True.");

console.log(car.length >=4);

// // Test 3

console.log("Is car starts with the letter 'c'? I predict True.");

console.log(car.startsWith('c'));
console.log("Is car doesn't start with letter 'b'? I predict True.");

console.log(car.startsWith('b'));

// Test 4

console.log("Is car in upper case? I predict True.");

console.log(car.toUpperCase() === "car");

console.log("Is car in lower case? I predict True.");

console.log(car.toLocaleLowerCase() ==="car");
// Test 5
console.log("Is car == 'suzuki'? I predict True.");

console.log(car == 'suzuki');
console.log("Is car !== 'suzuki'? I predict True.");

console.log(car !== 'suzuki');

