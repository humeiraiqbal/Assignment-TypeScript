"use strict";
// Name Cases: Store a person’s name in a variable, and then print that person’s name in lowercase, uppercase, and titlecase.
Object.defineProperty(exports, "__esModule", { value: true });
let personname = "Humeira Iqbal";
let lowercase = personname.toLowerCase();
console.log(personname.toLowerCase());
