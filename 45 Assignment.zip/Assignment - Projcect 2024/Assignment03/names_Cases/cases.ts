// Name Cases: Store a person’s name in a variable, and then print that person’s name in lowercase, uppercase, and titlecase.

//LOWER CASE
let personname: string = "Humeira Iqbal";
let lowercase: string = personname.toLowerCase();
console.log(personname.toLowerCase())

//UPPERCASE
let uppercase: string = personname.toUpperCase();
console.log(personname.toUpperCase())

//TITLECASE
let titlecase: string = ""