// Addition:
const additionResult = 4 + 4;
console.log("Addition Result: " + additionResult);
//Subtraction:
const subtractionResult = 12 - 4;
console.log("Subtraction Result: " + subtractionResult);
//Multiplication:
const multiplicationResult = 2 * 4;
console.log("Multiplication Result: " + multiplicationResult);
//Division:
const divisionResult = 2 * 4;
console.log("Division Result: " + divisionResult);
export {};
