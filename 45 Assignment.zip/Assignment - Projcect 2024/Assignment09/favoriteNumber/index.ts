//Favorite Number: Store your favorite number in a variable. Then, using that variable, create a message that reveals your favorite number. Print that message.


let favoriteNumber: number = 7;
let message: string = "My favorite number is"
console.log(`${message} : ${favoriteNumber}`)