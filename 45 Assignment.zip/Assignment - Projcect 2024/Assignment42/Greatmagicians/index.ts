/*Great Magicians: Start with a copy of your program from Exercise 41. */



let magicians_names: string[] = [ "Nick", "Andrew", "John", "Brian"];

console.log(magicians_names);


/*Write a function called make_great() that modifies the array of magicians by adding the phrase the Great to each magician’s name.*/

// _________________________________________________________________________________________
console.log("FOR LOOP FIRST METHOD");

function make_great1(modified_magicians:string[]) : void{
for (let i=0 ; i< magicians_names.length; i++)
   {
console.log(`${magicians_names[i]} the great`);
 }
    
}

make_great1(magicians_names);

//___II METHOD_______________________________________________________________________________
console.log("FOR LOOP FIRST METHOD");
function make_great(magicians: string[]): void {

    for (let magician of magicians) {
     console.log(`The great ${magician}`);
     
 
}
};
    

make_great(magicians_names);




//__________________________________________________________________________________
/*Call show_magicians() to see that the list has actually been 
modified.*/


function show_magician(magicians:string[]) : void
{ 
    for (let i=0; i< magicians.length;  i++) {
        
        console.log(magicians[i]);
    }
  
}

console.log( "Original Array");

show_magician(magicians_names);

console.log("Modified Array");

make_great(magicians_names)



