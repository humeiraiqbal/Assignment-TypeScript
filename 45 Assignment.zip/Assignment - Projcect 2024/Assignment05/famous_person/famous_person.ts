let famous_person: string = "Abraham Lincoln"
let message: string = "All that I am, or hope to be, I owe to my angel mother"
console.log(message)