let famous_person = "Abraham Lincoln";
let message = "All that I am, or hope to be, I owe to my angel mother";
console.log(message);
export {};
