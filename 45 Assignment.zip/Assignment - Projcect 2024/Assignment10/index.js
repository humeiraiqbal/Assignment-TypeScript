"use strict";
//Adding Comments: Choose two of the programs you’ve written, and add at least one comment to each. If you don’t have anything specific to write because your programs are too simple at this point, just add your name and the current date at the top of each program file. Then write one sentence describing what the program does.
// One way to add comment is mannually type double slash i.e//
// Second way to add comment is ctrl+
let personname = "Humeira Iqbal";
let lowercase = personname.toLowerCase();
console.log(personname.toLowerCase());
//If you want some specific part [ line 9 and line 10] to be comment out use /* before i.e for opening and */after i.e for closing
/*let uppercase: string = personname.toUpperCase();
console.log(personname.toUpperCase())*/
let titlecase = "";
// to remove comment just write ctrl & forward slash i.e/
