// Favorite Fruit: Make a array of your favorite fruits, and then write a series of independent if statements that check for certain fruits in your array.


// • Make a array of your three favorite fruits and call it favorite_fruits.
let favorite_Fruit: string[] = ["Banana","Orange","Grapes"];

if (favorite_Fruit.includes("Banana")) 
    {console.log("I really like bananas!")}


// • Write five if statements. Each should check whether a certain kind of fruit is in your array. If the fruit is in your array, the if block should print a statement, such as You really like bananas!
// "Guava","Apple"

if (favorite_Fruit.includes("Orange")) 
    {console.log("I really like oranges!")}


if (favorite_Fruit.includes("Grapes")) 
    {console.log("I really like grapes!")}

if (favorite_Fruit.includes("Guava")) 
    {console.log("I really like guavas!")}

if (favorite_Fruit.includes("Apple")) 
    {console.log("I really like apples!")}