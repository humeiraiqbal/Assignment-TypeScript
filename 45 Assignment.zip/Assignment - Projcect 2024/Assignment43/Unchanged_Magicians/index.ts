//43. Unchanged Magicians: Start with your work from Exercise 42.//
let magicians_names: string[] = [ "Nick", "Andrew", "John", "Brian"];
function make_great(magicians: string[]): void {

   for (let magician of magicians) {
    console.log(`The great ${magician}`);
    

}
};
   

make_great(magicians_names);
/*___________________________________________________________________________________*/


// Call the function make_great() with a copy of the array of magicians’ names.
//Because the original array will be unchanged, return the new array and store it in a separate array. 


function copy_make_great(){
    
let copy_magicians_names=[]  =[...magicians_names] ;

return magicians_names;

}
copy_make_great();
console.log(copy_make_great());




// Call show_magicians() with each array to show that you have one array of the original names and one array with 
// the Great added to each magician’s name.


function show_magician(magicians: string[] )
{

for (let i= 0; i< magicians.length; i++){

   
   console.log(magicians[i]);
    
} 
}

show_magician(magicians_names);
// _________________________________________________________________________________________
console.log('Original Array');

show_magician(magicians_names);


console.log('Modified Array');

make_great(magicians_names)



