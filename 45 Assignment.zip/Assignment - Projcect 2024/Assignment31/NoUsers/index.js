"use strict";
// No Users: Add an if test to Exercise 30 to make sure the list of users is not empty.
Object.defineProperty(exports, "__esModule", { value: true });
let userNames = ["Admin", "Ameen", "Mubashir", "Bilal", "Fahad"];
// • If the list is empty, print the message We need to find some users!
if (userNames.length === 0) {
    console.log("We need to find some users!");
}
// • Remove all of the usernames from your array, and make sure the correct message is printed.
else {
    userNames = [];
    console.log("We need to find some users!");
}
