// Dinner Guests: Working with one of the programs from Exercises 14 through 18, print a message indicating the number of people you are inviting to dinner.
var guestList = ["Roohi", "Bushra", "Rabia", "Adeeba", "Saira", "Sana", "Saba"];
/*console.log(guestList.splice(0,5));
let newguestList =guestList
console.log( newguestList);
console.log(`Sorry we haven't got bigger table, so we are inviting 2 persons only`)



while (guestList.length > 2){

let removeGuests = guestList.pop();
// console.log(removeGuests)
console.log("Dear Ms. " , removeGuests , "Sorry You are not invited");

}

for ( let i=0; i < guestList.length; i++) {

    console.log( "Dear Ms.\n" , guestList[i] , "\n You are still invited for the dinner. \n Thank You ");
}


guestList.splice(0,2);

console.log(guestList);*/
console.log("The number of persons invitited for Dinner is", guestList.length);
