let Languages = ["Chinese", "Turkish", "Japanese", "Urdu"];
console.log(Languages[4]);
export {};
